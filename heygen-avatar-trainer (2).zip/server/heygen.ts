/**
 * LiveAvatar API service (by HeyGen)
 * Base URL: https://api.liveavatar.com
 * Auth: x-api-key header
 */

const LIVEAVATAR_API_URL = "https://api.liveavatar.com";
const HEYGEN_API_KEY = process.env.HEYGEN_API_KEY ?? "";

function headers(extra: Record<string, string> = {}) {
  return { "Content-Type": "application/json", "x-api-key": HEYGEN_API_KEY, ...extra };
}

// ─── Session Token ────────────────────────────────────────────────────────────

export interface CreateSessionTokenRequest {
  avatar_id: string;
  mode: "FULL" | "LITE" | "CUSTOM";
  avatar_persona?: {
    name?: string;
    system_prompt?: string;
    voice_id?: string;
    context_id?: string;
    language?: string;
  };
  interactivity_type?: "CONVERSATIONAL" | "PUSH_TO_TALK";
  llm_configuration_id?: string;
  is_sandbox?: boolean;
}

export interface SessionTokenResponse {
  session_id: string;
  session_token: string;
}

export async function createSessionToken(req: CreateSessionTokenRequest): Promise<SessionTokenResponse> {
  const response = await fetch(`${LIVEAVATAR_API_URL}/v1/sessions/token`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify(req),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`LiveAvatar create token failed: ${response.status} ${error}`);
  }

  const data = await response.json();
  if (data.code !== 1000) {
    throw new Error(`LiveAvatar create token error: ${data.message}`);
  }
  return data.data as SessionTokenResponse;
}

// ─── Start Session ────────────────────────────────────────────────────────────

export interface StartSessionResponse {
  session_id: string;
  livekit_url: string;
  livekit_client_token: string;
  max_session_duration: number;
}

export async function startSession(sessionToken: string): Promise<StartSessionResponse> {
  const response = await fetch(`${LIVEAVATAR_API_URL}/v1/sessions/start`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${sessionToken}`,
    },
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`LiveAvatar start session failed: ${response.status} ${error}`);
  }

  const data = await response.json();
  if (data.code !== 1000) {
    throw new Error(`LiveAvatar start session error: ${data.message}`);
  }
  return data.data as StartSessionResponse;
}

// ─── Stop Session ─────────────────────────────────────────────────────────────

export async function stopSession(sessionToken: string): Promise<void> {
  const response = await fetch(`${LIVEAVATAR_API_URL}/v1/sessions/stop`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${sessionToken}`,
    },
  });

  if (!response.ok) {
    console.warn(`LiveAvatar stop session failed: ${response.status}`);
  }
}

// ─── Avatar List ──────────────────────────────────────────────────────────────

export interface LiveAvatar {
  id: string;
  name: string;
  preview_url: string;
  status: string;
  is_expired: boolean;
  default_voice?: {
    id: string;
    name: string;
    language: string;
    gender: string;
    preview_url?: string;
  };
}

export async function listPublicAvatars(page = 1, pageSize = 20): Promise<{ count: number; results: LiveAvatar[] }> {
  const response = await fetch(
    `${LIVEAVATAR_API_URL}/v1/avatars/public?page=${page}&page_size=${pageSize}`,
    { headers: headers() }
  );

  if (!response.ok) {
    throw new Error(`LiveAvatar list avatars failed: ${response.status}`);
  }

  const data = await response.json();
  return data.data as { count: number; results: LiveAvatar[] };
}

export async function listUserAvatars(): Promise<LiveAvatar[]> {
  const response = await fetch(`${LIVEAVATAR_API_URL}/v1/avatars`, { headers: headers() });
  if (!response.ok) return [];
  const data = await response.json();
  return (data.data?.results ?? []) as LiveAvatar[];
}

// ─── Contexts (Knowledge Base) ────────────────────────────────────────────────

export interface Context {
  id: string;
  name: string;
  created_at: string;
}

export async function listContexts(): Promise<Context[]> {
  const response = await fetch(`${LIVEAVATAR_API_URL}/v1/contexts`, { headers: headers() });
  if (!response.ok) return [];
  const data = await response.json();
  return (data.data?.results ?? []) as Context[];
}

export interface CreateContextOptions {
  name: string;
  prompt: string;
  opening_text: string;
  content?: string;
}

export async function createContext(opts: CreateContextOptions): Promise<string> {
  const response = await fetch(`${LIVEAVATAR_API_URL}/v1/contexts`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify({
      name: opts.name,
      prompt: opts.prompt,
      opening_text: opts.opening_text,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`LiveAvatar create context failed: ${response.status} ${error}`);
  }

  const data = await response.json();
  return data.data?.id as string;
}

export interface UpdateContextOptions {
  name?: string;
  prompt?: string;
  opening_text?: string;
}

export async function updateContext(id: string, opts: UpdateContextOptions): Promise<void> {
  const response = await fetch(`${LIVEAVATAR_API_URL}/v1/contexts/${id}`, {
    method: "PATCH",
    headers: headers(),
    body: JSON.stringify(opts),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`LiveAvatar update context failed: ${response.status} ${error}`);
  }
}

export async function deleteContext(id: string): Promise<void> {
  const response = await fetch(`${LIVEAVATAR_API_URL}/v1/contexts/${id}`, {
    method: "DELETE",
    headers: headers(),
  });
  if (!response.ok) {
    console.warn(`LiveAvatar delete context failed: ${response.status}`);
  }
}

// ─── Voices ───────────────────────────────────────────────────────────────────

export interface Voice {
  id: string;
  name: string;
  language: string;
  gender: string;
  preview_url?: string;
}

export async function listVoices(): Promise<Voice[]> {
  const response = await fetch(`${LIVEAVATAR_API_URL}/v1/voices`, { headers: headers() });
  if (!response.ok) return [];
  const data = await response.json();
  return (data.data?.results ?? []) as Voice[];
}
