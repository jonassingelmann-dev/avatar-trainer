import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import * as heygen from "./heygen";
import { storagePut } from "./storage";

function randomCode(length = 8): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Sessions ──────────────────────────────────────────────────────────────
  sessions: router({
    list: publicProcedure.query(() => db.getAllSessions()),

    getByCode: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(({ input }) => db.getSessionByCode(input.code)),

    create: publicProcedure
      .input(
        z.object({
          title: z.string().min(1).max(255),
          description: z.string().optional(),
          avatarId: z.string(),
          avatarName: z.string(),
          avatarPreviewUrl: z.string().optional(),
          mode: z.enum(["train", "challenge", "ask", "watch"]),
          language: z.string().default("en"),
          voiceId: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const sessionCode = randomCode(8);
        const id = await db.createSession({
          sessionCode,
          title: input.title,
          description: input.description ?? null,
          avatarId: input.avatarId,
          avatarName: input.avatarName,
          avatarPreviewUrl: input.avatarPreviewUrl ?? null,
          mode: input.mode,
          language: input.language,
          voiceId: input.voiceId ?? null,
          knowledgeBaseId: null,
          systemPrompt: null,
          isActive: true,
        });
        return { id, sessionCode };
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().min(1).max(255).optional(),
          description: z.string().optional(),
          mode: z.enum(["train", "challenge", "ask", "watch"]).optional(),
          language: z.string().optional(),
          voiceId: z.string().optional(),
          knowledgeBaseId: z.string().optional(),
          systemPrompt: z.string().optional(),
        })
      )
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateSession(id, data);
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteSessionById(input.id)),
  }),

  // ─── Documents ─────────────────────────────────────────────────────────────
  documents: router({
    list: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(({ input }) => db.getDocumentsBySession(input.sessionId)),

    upload: publicProcedure
      .input(
        z.object({
          sessionId: z.number(),
          fileName: z.string(),
          fileBase64: z.string(),
          mimeType: z.string(),
          fileSize: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        const buffer = Buffer.from(input.fileBase64, "base64");
        const suffix = Math.random().toString(36).slice(2, 8);
        const fileKey = `sessions/${input.sessionId}/docs/${suffix}-${input.fileName}`;
        const { url } = await storagePut(fileKey, buffer, input.mimeType);

        let extractedText: string | null = null;
        if (input.mimeType === "text/plain") {
          extractedText = buffer.toString("utf-8");
        }

        const id = await db.createDocument({
          sessionId: input.sessionId,
          fileName: input.fileName,
          fileUrl: url,
          fileSize: input.fileSize,
          mimeType: input.mimeType,
          extractedText,
        });

        return { id, url };
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteDocument(input.id)),
  }),

  // ─── LiveAvatar (HeyGen) ───────────────────────────────────────────────────
  heygen: router({
    // Create session token for client-side LiveKit connection
    createSessionToken: publicProcedure
      .input(
        z.object({
          avatarId: z.string(),
          mode: z.enum(["FULL", "LITE", "CUSTOM"]).default("FULL"),
          systemPrompt: z.string().optional(),
          contextId: z.string().optional(),
          voiceId: z.string().optional(),
          language: z.string().default("en"),
        })
      )
      .mutation(async ({ input }) => {
        const result = await heygen.createSessionToken({
          avatar_id: input.avatarId,
          mode: input.mode,
          avatar_persona: {
            system_prompt: input.systemPrompt,
            context_id: input.contextId,
            voice_id: input.voiceId,
            language: input.language,
          },
          interactivity_type: "CONVERSATIONAL",
        });
        return result;
      }),

    // Start the session and get LiveKit connection details
    startSession: publicProcedure
      .input(z.object({ sessionToken: z.string() }))
      .mutation(async ({ input }) => {
        return heygen.startSession(input.sessionToken);
      }),

    // Stop a session
    stopSession: publicProcedure
      .input(z.object({ sessionToken: z.string() }))
      .mutation(async ({ input }) => {
        await heygen.stopSession(input.sessionToken);
        return { success: true };
      }),

    // List available public avatars
    listAvatars: publicProcedure
      .input(z.object({ page: z.number().default(1) }).optional())
      .query(({ input }) => heygen.listPublicAvatars(input?.page ?? 1, 20)),

    // List voices
    listVoices: publicProcedure.query(() => heygen.listVoices()),

    // Build context (knowledge base) from session documents
    buildContext: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(async ({ input }) => {
        const session = await db.getSessionById(input.sessionId);
        if (!session) throw new Error("Session not found");

        const docs = await db.getDocumentsBySession(input.sessionId);
        if (docs.length === 0) throw new Error("No documents to build context from");

        const combinedText = docs
          .filter((d) => d.extractedText)
          .map((d) => `=== ${d.fileName} ===\n${d.extractedText}`)
          .join("\n\n");

        if (!combinedText) throw new Error("No text could be extracted from documents");

        // Build mode-specific system prompt and opening text
        const modePrompts: Record<string, { prompt: string; opening_text: string }> = {
          train: {
            prompt: `You are a knowledgeable and engaging teacher. Use the provided knowledge base to teach the learner. Explain concepts clearly, use examples, and encourage questions. Knowledge base:\n\n${combinedText}`,
            opening_text: `Hello! I'm your personal trainer for "${session.title}". I've studied all the materials and I'm ready to guide you through the content. What would you like to learn first?`,
          },
          challenge: {
            prompt: `You are a quiz master. Use the provided knowledge base to quiz the learner with challenging questions. Give feedback on their answers and help them understand mistakes. Knowledge base:\n\n${combinedText}`,
            opening_text: `Welcome to the challenge session for "${session.title}"! I'll test your knowledge with questions based on the materials. Are you ready to begin?`,
          },
          ask: {
            prompt: `You are a helpful expert assistant. Answer questions about the provided knowledge base accurately and concisely. If a question is outside the knowledge base, say so honestly. Knowledge base:\n\n${combinedText}`,
            opening_text: `Hi! I'm your expert on "${session.title}". I've read all the materials and I'm here to answer any questions you have. What would you like to know?`,
          },
          watch: {
            prompt: `You are a professional presenter. Present the content from the knowledge base in an engaging, structured way. Summarize key points and highlight important information. Knowledge base:\n\n${combinedText}`,
            opening_text: `Welcome! Today I'll be presenting "${session.title}" for you. Sit back and I'll walk you through all the key information from the materials.`,
          },
        };

        const modeConfig = modePrompts[session.mode] ?? modePrompts.ask;
        const contextName = `Session-${session.sessionCode}-${session.mode}`;

        let contextId: string;
        if (session.knowledgeBaseId) {
          await heygen.updateContext(session.knowledgeBaseId, {
            name: contextName,
            prompt: modeConfig.prompt,
            opening_text: modeConfig.opening_text,
          });
          contextId = session.knowledgeBaseId;
        } else {
          contextId = await heygen.createContext({
            name: contextName,
            prompt: modeConfig.prompt,
            opening_text: modeConfig.opening_text,
          });
          await db.updateSession(input.sessionId, { knowledgeBaseId: contextId });
        }

        return { contextId };
      }),
  }),
});

export type AppRouter = typeof appRouter;
