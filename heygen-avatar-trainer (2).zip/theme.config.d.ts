export const themeColors: {
  primary:    { light: string; dark: string };
  secondary:  { light: string; dark: string };
  background: { light: string; dark: string };
  surface:    { light: string; dark: string };
  surface2:   { light: string; dark: string };
  foreground: { light: string; dark: string };
  muted:      { light: string; dark: string };
  border:     { light: string; dark: string };
  success:    { light: string; dark: string };
  warning:    { light: string; dark: string };
  error:      { light: string; dark: string };
  train:      { light: string; dark: string };
  challenge:  { light: string; dark: string };
  ask:        { light: string; dark: string };
  watch:      { light: string; dark: string };
};

declare const themeConfig: {
  themeColors: typeof themeColors;
};

export default themeConfig;
