/** @type {const} */
const themeColors = {
  primary:    { light: '#5B4FE9', dark: '#5B4FE9' },
  secondary:  { light: '#00C2A8', dark: '#00C2A8' },
  background: { light: '#0F0F1A', dark: '#0F0F1A' },
  surface:    { light: '#1A1A2E', dark: '#1A1A2E' },
  surface2:   { light: '#252540', dark: '#252540' },
  foreground: { light: '#F0F0FF', dark: '#F0F0FF' },
  muted:      { light: '#8888AA', dark: '#8888AA' },
  border:     { light: '#2E2E50', dark: '#2E2E50' },
  success:    { light: '#00C2A8', dark: '#00C2A8' },
  warning:    { light: '#FFB347', dark: '#FFB347' },
  error:      { light: '#FF6B6B', dark: '#FF6B6B' },
  // Mode accent colors
  train:      { light: '#5B4FE9', dark: '#5B4FE9' },
  challenge:  { light: '#FF6B6B', dark: '#FF6B6B' },
  ask:        { light: '#00C2A8', dark: '#00C2A8' },
  watch:      { light: '#FFB347', dark: '#FFB347' },
};

module.exports = { themeColors };
