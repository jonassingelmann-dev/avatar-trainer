/**
 * Unified type exports
 * Import shared types from this single entry point.
 */

export type * from "../drizzle/schema";
export * from "./_core/errors";

// ─── App-specific types ───────────────────────────────────────────────────────

export type SessionMode = "train" | "challenge" | "ask" | "watch";

export interface AvatarOption {
  avatar_id: string;
  avatar_name: string;
  gender: string;
  preview_image_url: string;
  preview_video_url: string;
  is_public: boolean;
}

export const MODE_CONFIG: Record<SessionMode, {
  label: string;
  description: string;
  icon: string;
  color: string;
}> = {
  train: {
    label: "Train",
    description: "The avatar teaches the learner based on uploaded content",
    icon: "school",
    color: "#5B4FE9",
  },
  challenge: {
    label: "Challenge",
    description: "The avatar quizzes and challenges the learner",
    icon: "quiz",
    color: "#FF6B35",
  },
  ask: {
    label: "Ask",
    description: "The learner can freely ask questions and get answers",
    icon: "chat",
    color: "#00C2A8",
  },
  watch: {
    label: "Watch",
    description: "The avatar presents content as a lecture",
    icon: "play-circle-filled",
    color: "#FFB347",
  },
};
