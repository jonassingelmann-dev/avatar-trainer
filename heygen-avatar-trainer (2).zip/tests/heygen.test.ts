import { describe, it, expect } from "vitest";
import "dotenv/config";

describe("LiveAvatar API Key Validation", () => {
  it("should list public avatars successfully", async () => {
    const apiKey = process.env.HEYGEN_API_KEY;
    expect(apiKey, "HEYGEN_API_KEY must be set").toBeTruthy();

    const response = await fetch("https://api.liveavatar.com/v1/avatars/public?page=1&page_size=5", {
      headers: { "x-api-key": apiKey! },
    });

    expect(response.status, `Expected 200 but got ${response.status}`).toBe(200);
    const data = await response.json();
    expect(data.code).toBe(1000);
    expect(data.data.count).toBeGreaterThan(0);
  }, 15000);
});
