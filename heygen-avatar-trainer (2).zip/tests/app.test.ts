import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── Mock environment ─────────────────────────────────────────────────────────
vi.stubEnv("HEYGEN_API_KEY", "b05eb3ae-dab4-4530-bfc4-22bcf2fc4895");
vi.stubEnv("DATABASE_URL", "");

// ─── Mock database so tests run without a real DB ────────────────────────────
vi.mock("../server/db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
  getAllSessions: vi.fn().mockResolvedValue([
    {
      id: 1,
      sessionCode: "ABC123",
      title: "Test Session",
      description: "A test session",
      avatarId: "avatar_001",
      avatarName: "Test Avatar",
      avatarPreviewUrl: null,
      mode: "train",
      language: "en",
      voiceId: null,
      knowledgeBaseId: null,
      systemPrompt: null,
      isActive: true,
      createdAt: new Date("2026-01-01"),
      updatedAt: new Date("2026-01-01"),
    },
  ]),
  getSessionByCode: vi.fn().mockImplementation((code: string) => {
    if (code === "ABC123") {
      return Promise.resolve({
        id: 1,
        sessionCode: "ABC123",
        title: "Test Session",
        mode: "train",
        avatarId: "avatar_001",
        avatarName: "Test Avatar",
        isActive: true,
      });
    }
    return Promise.resolve(null);
  }),
  getSessionById: vi.fn().mockImplementation((id: number) => {
    if (id === 1) {
      return Promise.resolve({
        id: 1,
        sessionCode: "ABC123",
        title: "Test Session",
        mode: "train",
        avatarId: "avatar_001",
        avatarName: "Test Avatar",
        isActive: true,
      });
    }
    return Promise.resolve(null);
  }),
  createSession: vi.fn().mockResolvedValue(1),
  updateSession: vi.fn().mockResolvedValue(undefined),
  deleteSessionById: vi.fn().mockResolvedValue(undefined),
  getDocumentsBySession: vi.fn().mockResolvedValue([]),
  createDocument: vi.fn().mockResolvedValue(1),
  deleteDocument: vi.fn().mockResolvedValue(undefined),
}));

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("Shared Types — MODE_CONFIG", () => {
  it("should export all 4 session modes", async () => {
    const { MODE_CONFIG } = await import("../shared/types");
    expect(Object.keys(MODE_CONFIG)).toEqual(["train", "challenge", "ask", "watch"]);
  });

  it("should have correct labels for each mode", async () => {
    const { MODE_CONFIG } = await import("../shared/types");
    expect(MODE_CONFIG.train.label).toBe("Train");
    expect(MODE_CONFIG.challenge.label).toBe("Challenge");
    expect(MODE_CONFIG.ask.label).toBe("Ask");
    expect(MODE_CONFIG.watch.label).toBe("Watch");
  });

  it("should have color defined for each mode", async () => {
    const { MODE_CONFIG } = await import("../shared/types");
    for (const mode of Object.values(MODE_CONFIG)) {
      expect(mode.color).toMatch(/^#[0-9A-Fa-f]{6}$/);
    }
  });

  it("should have description defined for each mode", async () => {
    const { MODE_CONFIG } = await import("../shared/types");
    for (const mode of Object.values(MODE_CONFIG)) {
      expect(mode.description.length).toBeGreaterThan(10);
    }
  });
});

describe("Database helpers (mocked)", () => {
  it("getAllSessions returns array", async () => {
    const { getAllSessions } = await import("../server/db");
    const sessions = await getAllSessions();
    expect(Array.isArray(sessions)).toBe(true);
    expect(sessions.length).toBe(1);
    expect(sessions[0].sessionCode).toBe("ABC123");
  });

  it("getSessionByCode returns session for valid code", async () => {
    const { getSessionByCode } = await import("../server/db");
    const session = await getSessionByCode("ABC123");
    expect(session).not.toBeNull();
    expect(session?.title).toBe("Test Session");
  });

  it("getSessionByCode returns null for invalid code", async () => {
    const { getSessionByCode } = await import("../server/db");
    const session = await getSessionByCode("INVALID");
    expect(session).toBeNull();
  });

  it("createSession returns numeric ID", async () => {
    const { createSession } = await import("../server/db");
    const id = await createSession({
      sessionCode: "XYZ999",
      title: "New Session",
      avatarId: "avatar_002",
      avatarName: "New Avatar",
      mode: "ask",
      language: "en",
      isActive: true,
    });
    expect(typeof id).toBe("number");
    expect(id).toBe(1);
  });
});

describe("HeyGen API service", () => {
  it("should build correct session token URL", () => {
    const baseUrl = "https://api.liveavatar.com/v1";
    const endpoint = `${baseUrl}/sessions/token`;
    expect(endpoint).toBe("https://api.liveavatar.com/v1/sessions/token");
  });

  it("should build correct system prompt for train mode", () => {
    const mode = "train";
    const prompts: Record<string, string> = {
      train: "You are a friendly and knowledgeable teacher.",
      challenge: "You are a quiz master.",
      ask: "You are a helpful assistant.",
      watch: "You are a presenter.",
    };
    expect(prompts[mode]).toContain("teacher");
  });

  it("should build correct system prompt for challenge mode", () => {
    const mode = "challenge";
    const prompts: Record<string, string> = {
      train: "You are a friendly and knowledgeable teacher.",
      challenge: "You are a quiz master.",
      ask: "You are a helpful assistant.",
      watch: "You are a presenter.",
    };
    expect(prompts[mode]).toContain("quiz");
  });

  it("should generate unique session codes", () => {
    const generateCode = () => Math.random().toString(36).substring(2, 8).toUpperCase();
    const codes = new Set(Array.from({ length: 100 }, generateCode));
    // With 100 codes of 6 chars, collisions should be extremely rare
    expect(codes.size).toBeGreaterThan(90);
  });
});

describe("Session code validation", () => {
  it("should accept alphanumeric codes", () => {
    const validCodes = ["ABC123", "XYZ999", "HELLO1", "TEST42"];
    for (const code of validCodes) {
      expect(/^[A-Z0-9]{4,8}$/.test(code)).toBe(true);
    }
  });

  it("should reject invalid codes", () => {
    const invalidCodes = ["", "ab", "!@#$%", "toolongcode12345"];
    const isValid = (code: string) => /^[A-Z0-9]{4,8}$/.test(code);
    for (const code of invalidCodes) {
      expect(isValid(code)).toBe(false);
    }
  });
});
