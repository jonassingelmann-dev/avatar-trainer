# HeyGen Avatar Trainer — Project TODO

## Setup & Infrastructure
- [x] Generate app logo and update branding
- [x] Update theme colors (dark indigo/teal palette)
- [x] Install HeyGen streaming avatar dependencies (@livekit/react-native, livekit-client)
- [x] Install document picker and file system dependencies
- [x] Configure app.config.ts with permissions (camera, microphone)
- [x] Set up backend API routes for session management
- [x] Set up database schema (sessions, documents)
- [x] Store HeyGen API key securely in backend environment

## Backend API
- [x] sessions.list — List all sessions
- [x] sessions.getByCode — Get session by code
- [x] sessions.create — Create new session
- [x] sessions.update — Update session
- [x] sessions.delete — Delete session
- [x] documents.list — List documents for session
- [x] documents.upload — Upload document (base64 + S3 storage)
- [x] documents.delete — Remove document
- [x] heygen.createSessionToken — Create LiveAvatar session token
- [x] heygen.startSession — Start LiveKit session
- [x] heygen.stopSession — Stop session
- [x] heygen.listAvatars — List available public avatars
- [x] heygen.listVoices — List available voices
- [x] heygen.buildContext — Build knowledge base from documents

## Navigation & Screens
- [x] Trainer tab navigation setup
- [x] Learner tab navigation setup
- [x] All routes registered in _layout.tsx

## Trainer Side
- [x] Trainer Home screen with session list
- [x] Empty state for no sessions
- [x] Create Session screen — title, description, mode selection
- [x] Avatar Selection modal (grid view)
- [x] Session Detail screen
- [x] Document upload (TXT, PDF, Word)
- [x] Document list with delete
- [x] Build knowledge base from documents
- [x] Share session code via system share sheet
- [x] Delete session functionality

## Learner Side
- [x] Learner tab — session code entry
- [x] Mode info cards (Train, Challenge, Ask, Watch)
- [x] Learner session screen — pre-session info, start button
- [x] Live avatar video via LiveKit
- [x] Chat message area with user/avatar bubbles
- [x] Text input for Ask/Challenge/Train modes
- [x] Microphone mute toggle
- [x] Session end with confirmation

## HeyGen Integration
- [x] HeyGen LiveAvatar API service (token creation, session management)
- [x] LiveKit room connection for video streaming
- [x] Avatar video display component (native + web)
- [x] Knowledge base creation from uploaded documents
- [x] Avatar list fetching and display
- [x] Session cleanup on unmount

## UI/UX Polish
- [x] Mode color coding (indigo/coral/teal/amber)
- [x] Dark theme throughout
- [x] Loading states and activity indicators
- [x] Error handling and user-friendly error messages
- [x] Haptic feedback on tab bar
- [x] TypeScript — zero errors

## Future Enhancements
- [ ] Voice input (push-to-talk) for learner
- [ ] Avatar video fullscreen mode
- [ ] Session analytics / history
- [ ] Multiple language support
- [ ] Voice selection per session

## Bug Fixes
- [x] Fix LiveAvatar context creation: add required `prompt` and `opening_text` fields to buildContext API call
- [x] Fix learner session on native: removed @livekit/react-native + react-native-webrtc entirely, native now uses WebView + livekit-client CDN (works in Expo Go without native linking)
- [x] Fix Android APK build failure: withAndroidWebRTCFix plugin correctly places configurations.all outside repositories block in build.gradle + pickFirsts in gradle.properties
